/* Task_18_4.c: Return the largest number
-----------------------------------------------------------------------------
A function int *find_largest(int a[], int n); when passed an array a
of length n, the function will return a pointer to the array’s largest
element. In main() define an array of 10 elements and take its elements
through user input. Pass this array to the defined function and print
the largest number on computer screen using its pointer returned from
the function.
-----------------------------------------------------------------------------
Written by Muhammad Anees (m.anees990011@gmail.com)
_____________________________________________________________________________
IDE: Visual Studio Code 1.72.0
_____________________________________________________________________________
C Compiler: gcc (Rev1, Built by MSYS2 project) 12.2.0
_____________________________________________________________________________*/

#include <stdio.h>
int *find_largest(int a[], int *n);
int main()
{
    int largest;
    int N=10;
    int arr[10];
    for (int i = 1; i < N; i++)
    {
        printf("Enter the number %d >> ", i);
        scanf("%d", &arr[i]);
    }
largest= *find_largest( arr, &N);
    printf("The largest number is %d.", largest);
    return 0;
}
int *find_largest(int a[], int *n)
{
    int *max;
    for (int i = 0; i < 10; i++)
    {
        if (a[i]>*max)
        {
            max=&a[i];
        }
    }
    return max;
}
// End Of Program
