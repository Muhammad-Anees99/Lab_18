/* Task_18_2.c: Pointer! Reverse the order of string
-----------------------------------------------------------------------------
A program that asks user to enter a string, reverse it using
pointer, and display it on computer screen.
-----------------------------------------------------------------------------
Written by Muhammad Anees (m.anees990011@gmail.com)
_____________________________________________________________________________
IDE: Visual Studio Code 1.72.0
_____________________________________________________________________________
C Compiler: gcc (Rev1, Built by MSYS2 project) 12.2.0
_____________________________________________________________________________*/

# include<stdio.h>
# include<string.h>
int main(){
    char *str;
    int count=0;
    printf("Enter the string >> ");
    gets(str);
    count=strlen(str);
    printf("String in reverse order is ");
    for (int i = count; i >= 0; i--)
    {
        printf("%c",*(str+i));
    }
    return 0;
}
// End Of Program