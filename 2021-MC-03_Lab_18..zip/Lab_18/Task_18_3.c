/* Task_18_3.c: Simplified Fraction
-----------------------------------------------------------------------------
A function void reduce(int *numerator, int *denominator); when passed
a numerator and denominator of a fraction as pointers, the function reduces
it to simplify it. In main() define take a fraction through user input.
Pass this fraction to the defined function and print the simplified
fraction on computer screen after returning from the defined function.
-----------------------------------------------------------------------------
Written by Muhammad Anees (m.anees990011@gmail.com)
_____________________________________________________________________________
IDE: Visual Studio Code 1.72.0
_____________________________________________________________________________
C Compiler: gcc (Rev1, Built by MSYS2 project) 12.2.0
_____________________________________________________________________________*/

# include<stdio.h>
int Find_GCD(int, int);
void reduce(int *numerator, int *denominator);

int main(){
 int numerator,denominator;
    printf("Enter the fraction >> ");
    scanf("%d/%d",&numerator,&denominator);
    reduce(&numerator, &denominator);
    printf("The simplified fraction is %d/%d.",numerator,denominator);
    return 0;
}
int Find_GCD(int num1, int num2)
{
    int gcd;
    if (num1 == 0)
    {
        return num2;
    }
    else if (num2 == 0)
    {
        return num1;
    }

    if (num1 > num2)
    {
      gcd=  Find_GCD(num1 % num2, num2);
    }
    else 
    {
       gcd= Find_GCD(num2 % num1, num1);
    }
    return gcd;
}
void reduce(int *numerator, int *denominator)
{
    int gcd=0;
    gcd=Find_GCD( *numerator,*denominator);
    *numerator/=gcd;
    *denominator/=gcd;

}
// End Of Program