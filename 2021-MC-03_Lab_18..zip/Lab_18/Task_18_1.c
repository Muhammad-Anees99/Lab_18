/* Task_18_1.c: Pointer! Sum the array.
-----------------------------------------------------------------------------
A program that asks user to enter an array of 7 elements, computes
its sum using pointer, and display it on computer screen.
-----------------------------------------------------------------------------
Written by Muhammad Anees (m.anees990011@gmail.com)
_____________________________________________________________________________
IDE: Visual Studio Code 1.72.0
_____________________________________________________________________________
C Compiler: gcc (Rev1, Built by MSYS2 project) 12.2.0
_____________________________________________________________________________*/

#include <stdio.h>
int main()
{
    int arr[7];
    int *ptr = arr;
    for (int i = 1; i <= 7; i++)
    {
        printf("Enter the number %d >> ", i);
        scanf("%d", &arr[i]);
        *ptr += arr[i];
    }
    printf("Sum of array elements is %d.", *ptr);
    return 0;
}
// End Of Program